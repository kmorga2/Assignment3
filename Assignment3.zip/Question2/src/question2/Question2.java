// this program will print the authors name, email, book, gender, price, and qty in stock
package question2;

public class Question2{

    public static void main(String[] args) {
        Author1 washington = new Author1("Nicki Washington" , "washingtonn@winthrop.edu ", 'f');
        Book1 toc = new Book1("Stay Prepped: 10 steps to Succeeding in College (and Having a Ball Doing It)!" , washington, 14.95, 1908);
       
        System.out.println(toc.toString());
    }
}

   