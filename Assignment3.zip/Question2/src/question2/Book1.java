package question2;

public class Book1{
    private final String name;
    private final Author1 author;
    private final double price;
    private final int qtyInStock;
    
    public Book1(String name, Author1 author, double price, int qtyInStock){
        
        this.name = name;
        this.author = author;
        this.price = price;
        this.qtyInStock = qtyInStock;
    }
    //method that gets the name
    public String getName(){
        return name;
       
    }
    // method that gets the author
    public Author1 getAuthor(){
        return author;
    }
    // method that gets the price
    public double getPrice(){
        return price;
    }
    // method that sets the price
    public void setPrice(double price){
       price = this.price;
       
    }
    // method that gets teh qty in stock
    public int getQtyInStock(){
        return qtyInStock;
    }
    // method that sets qty in stock
    public void setQtyInStock( int qtyInStock){
        qtyInStock = this.qtyInStock;
    }
    // displays name of book, price and in stock provided in question2
    @Override
    public String toString(){
        
        String aBook = "Name of book: " + name + "\n" + author + "\nPrice: " + price + "\nIn stock : " + qtyInStock;
        return aBook;
    }
}