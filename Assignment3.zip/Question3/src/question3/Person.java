package question3;

// gets name of person, age, and gender
public class Person{
    protected String myName;
    protected int myAge;
    protected String myGender;
    
    public Person(String name, int age, String gender){
        myName= name;
        myAge = age;
        myGender = gender;
    }
    // prints the information provided from person and question 3
    @Override
    public String toString() {
        return myName + ", age: " + myAge + ", gender: " + myGender;
    
    }
    // method that gets name
    public String getName(){
        return myName;
    }
    // method that gets age
    public int getAge(){
        return myAge;
    }
    //method that gets gender
    public String getGender(){
        return myGender;
    }
    //method that sets name
    public void setName(){
        
    }
    //method that sets age
    public void setAge(){
        
    }
    //method that sets gender
    public void setGender(){
        
    }


}