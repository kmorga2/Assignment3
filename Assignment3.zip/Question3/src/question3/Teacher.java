package question3;
// class that provides the information for subject and salary
public class Teacher extends Person{
       protected String mySubject;
       protected double mySalary;
    public Teacher(String name, int age, String gender, String subject, double salary ) {
        super(name, age, gender);
        this.mySubject = subject;
        this.mySalary = salary;
                
    }
    // gets the value for mySalary
    public double getSalary(){
        return mySalary;
    }
    //method that gets the subject
    public String getSubject(){
        return mySubject;
    }
    //method that sets the value for salary
    public void setSalary(){
        
    }
    // method that sets subject
    public void setSubject(){
        
    }
    // prints the information provided from question 3 and the data from other classes
    @Override
    public String toString(){
        
        String mrJava = super.toString() + ", Subject: " + mySubject + " , Salary: " + mySalary;
        return mrJava;
    }
}
