
package question3;

public class CollegeStudent extends Student{
    protected String myMajor;
    protected int myYear;
    public CollegeStudent(String name, int age, String gender, String idNum, double gpa, int year, String major) {
        super(name, age, gender, idNum, gpa);
       this.myYear = year;
       this.myMajor = major;
    }
// gets the year    
    public int getYear(){
        return myYear;
    }
    // method that gets the major
    public String getMajor(){
        return myMajor;
    }
    //method that sets the year
     public void setYear(){
       
    }
     // method that sets the major
    public void setMajor(){
        
    }
    // sets up message for college student with information in question3
    @Override
    public String toString(){
        String ima = super.toString() +  ", ID#: " + myIdNum + ", GPA:  " + myGPA + ", Year : " + myYear + " , Major: " + myMajor;
        return ima;
    }
}
