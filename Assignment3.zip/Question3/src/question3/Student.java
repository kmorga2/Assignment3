package question3;

// class that gets student id number and gpa
public class Student extends Person {
    protected String myIdNum;
    protected double myGPA;
    
   
    public Student(String name, int age, String gender, String idNum, double gpa){
        super(name, age, gender);
        
        myIdNum = idNum;
        myGPA = gpa;
    }
    //method that gets id number
    public String myIdNum(){
        return myIdNum;
    }
    //method that gets gpa
    public double getGPA(){
        return myGPA;
    }
    //method that sets id number
    public void setIdNum(String id){
        id = myIdNum;
    }
    //method that sets gpa
    public void setGPA(double gpa){
        gpa = myGPA;
    }
    
  }
