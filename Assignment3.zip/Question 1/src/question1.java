//this program will print the authors name, email and gender
public class question1 extends Author{
    public static void main(String[] args){
     // gives the authors name, email, and gender
        Author author1 = new Author("Nicki Washington" , "washingtonn@winthrop.edu ", 'f'); 
        System.out.println(author1.toString());
    }
    // calls back the information from Author
    public question1(String name, String email, char gender) {
        super(name, email, gender);
    }
}
