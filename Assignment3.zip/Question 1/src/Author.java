
public class Author{
    private final String name;
    private final String email;
    private final char gender;
    
    
    public Author(String name, String email, char gender){
        this.name = name;
        this.gender = gender;
        this.email = email;
    }
    // method that gets the name
    public String getName(){
        return name;
    }
    // method that gets the email
    public String getEmail(){
        return email;
    }
    // method that sets email
    public void setEmail(String email){
       
    }
    //method that gets gender
    public char getGender(){
        return gender;
    }
    // displays name, age and gender provided in question1
    @Override
    public String toString(){
      
        String Hoopla = "Author: " + name +  "\nEmail: " + email + "\nGender: " +gender ;
        return Hoopla;
    }
}